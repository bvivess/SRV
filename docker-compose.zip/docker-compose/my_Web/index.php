<?php
	echo "Hello world !";
?>
