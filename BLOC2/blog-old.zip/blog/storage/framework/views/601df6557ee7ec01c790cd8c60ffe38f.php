<table>
    <tr  >
        <td><?php echo e($post->id); ?></td>
        <td><?php echo e($post->title); ?></td>
        <td><?php echo e($post->posted); ?></td>
        <td><?php echo e($post->content); ?></td>
        <td><?php echo e($post->created_at); ?></td>
        <td><?php echo e($post->updated_at); ?></td>
        <td></td>
    </tr>
</table>
<?php /**PATH C:\laragon\www\blog\resources\views/post/show.blade.php ENDPATH**/ ?>