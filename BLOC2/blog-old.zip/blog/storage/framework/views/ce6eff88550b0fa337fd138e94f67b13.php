<table>
    <tr  >
        <td><?php echo e($category->id); ?></td>
        <td><?php echo e($category->title); ?></td>
        <td><?php echo e($category->url_clean); ?></td>
        <td><?php echo e($category->created_at); ?></td>
        <td><?php echo e($category->updated_at); ?></td>
        <td></td>
    </tr>
</table>
<?php /**PATH C:\laragon\www\blog\resources\views/category/show.blade.php ENDPATH**/ ?>