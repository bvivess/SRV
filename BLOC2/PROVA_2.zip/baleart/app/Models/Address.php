<?php

namespace App\Models;

use App\Models\Zone;
use App\Models\Island;
use App\Models\Service;
use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    public function service()
    {
        return $this->hasOne(Service::class);
    }

    public function island()
    {
        return $this->belongsTo(Island::class);
    }

    public function zone()
    {
        return $this->belongsTo(Zone::class);
    }
}
