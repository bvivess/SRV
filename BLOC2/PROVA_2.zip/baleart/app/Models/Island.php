<?php

namespace App\Models;

use App\Models\Municipality;
use Illuminate\Database\Eloquent\Model;

class Island extends Model
{
    public function municipality()
    {
        return $this->hasMany(Municipality::class);
    }
}
