<?php

namespace Database\Seeders;


use App\Models\User;
use App\Models\Zone;
use App\Models\Space;
use App\Models\Address;
use App\Models\SpaceType;
use App\Models\Municipality;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class SpaceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Des d'un arxiu JSON
        $jsonData = file_get_contents('c:\\temp\\baleart\\espais.json');
        $spaces = json_decode($jsonData, true);

        foreach ($spaces as $space) {
            $municipalityId = Municipality::where('name', $space['municipi'])->first()->id ?? 1;
            $zoneId = Zone::where('name', $space['zona'])->first()->id;
            $adreca = new Address();
            $adreca->name =  $space['adreca'];
            $adreca->municipality_id = $municipalityId;
            $adreca->zone_id = $zoneId;
            $adreca->save();
            $addrecaId = $adreca->id;
            $espaiTypeId = SpaceType::where('description_CA', $space['tipus'])->first()->id;
            $userId = User::where('email', $space['gestor'])->first()->id   ?? 1;

            Space::create([
                'name' => $space['nom'],
                'regNumber' => $space['registre'],
                'observation_CA' => $space['descripcions/cat'],
                'observation_ES' => $space['descripcions/esp'],
                'observation_EN' => $space['descripcions/eng'],
                'phone' => $space['telefon'],
                'email' => $space['email'],
                'website' => $space['web'],
                'accessType' => 'y',
                'totalValuations' => 0,
                'totalScore' => 0,
                'space_type_id' => $espaiTypeId,
                'address_id' => $addrecaId,
                'user_id' => $userId
            ]);
        }
    }
}
